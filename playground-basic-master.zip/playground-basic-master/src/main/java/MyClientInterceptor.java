import java.io.IOException;

import ca.uhn.fhir.rest.client.api.IClientInterceptor;
import ca.uhn.fhir.rest.client.api.IHttpRequest;
import ca.uhn.fhir.rest.client.api.IHttpResponse;


public class MyClientInterceptor implements IClientInterceptor
{
	private long startTime;
	private long timeTaken;

	@Override
	public void interceptRequest(IHttpRequest theRequest)
	{
		startTime = System.currentTimeMillis();
	}

	@Override
	public void interceptResponse(IHttpResponse theResponse) throws IOException
	{
		timeTaken = System.currentTimeMillis() - startTime;
	}

	public long getTimeTaken()
	{
		return timeTaken;
	}
}
