import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.rest.api.CacheControlDirective;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import ca.uhn.fhir.rest.client.interceptor.LoggingInterceptor;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.StringType;
import org.hl7.fhir.r4.model.Bundle.BundleEntryComponent;
import org.hl7.fhir.utilities.TextFile;
import org.hl7.fhir.r4.model.HumanName;


public class SampleClient
{
    // Create a FHIR client
    private static FhirContext fhirContext = FhirContext.forR4();
    private static IGenericClient client = fhirContext.newRestfulGenericClient("http://hapi.fhir.org/baseR4");

    public static void main(String[] theArgs)
    {
//        client.registerInterceptor(new LoggingInterceptor(false));

        boolean noCache = false;
        
        System.out.println("***********************************************************");
        System.out.println("*********  Running first test, use caching ****************");
        System.out.println("***********************************************************");
        long averageTime = runTest(noCache);
        System.out.println("Average time for FIRST run is [" + averageTime + "] ms\n\n");
        
        System.out.println("***********************************************************");
        System.out.println("*********  Running second test, use caching ***************");
        System.out.println("***********************************************************");
        averageTime = runTest(noCache);
        System.out.println("Average time for SECOND run is [" + averageTime + "] ms\n\n");

        System.out.println("***********************************************************");
        System.out.println("*********  Running third test, caching disabled ***********");
        System.out.println("***********************************************************");
        // caching disabled;
        noCache = true;
        averageTime = runTest(noCache);
        System.out.println("Average time THIRD run, caching disabled, is [" + averageTime + "] ms");
    }

    
    private static long runTest(boolean noCache)
    {
        ArrayList<Long> times = new ArrayList<Long>(); 
        
        // read file with names, line by line;
		BufferedReader reader;
		try
		{
			reader = new BufferedReader(new FileReader("c:/florin/names.txt"));
			String name = reader.readLine();
			while (name != null)
			{
		        // for each name, search patient;
		        long timeTaken = getSearchTime(name, noCache);
		        System.out.println("  took " + timeTaken + " ms");
				times.add(new Long(timeTaken));
		        
				// read next name;
				name = reader.readLine();
			}
			reader.close();
		}
		catch (IOException e)
		{
			System.out.println("Error reading file: " + e.getMessage());
			e.printStackTrace();
		}
        
		// print average time for all names in the file;
		long averageTime = calcAverage(times);
        return averageTime;
    }

    
    @SuppressWarnings("unused")
	private static Bundle searchPatient(String lastName)
    {
    	if (lastName == null || lastName.isEmpty())
    	{
            System.out.println("Error: cannot search for empty last name.");
    		return null;
    	}
    	
		System.out.println("	Searching for patient [" + lastName.toUpperCase() + "]");
        client.registerInterceptor(new MyClientInterceptor());

		// Search for Patient resources
        Bundle response = client
                .search()
                .forResource("Patient")
                .where(Patient.FAMILY.matches().value(lastName.toUpperCase()))
//              .where(Patient.FAMILY.matches().value("SMITH"))
                .returnBundle(Bundle.class)
                .execute();

        return response;
    }

    
    private static long getSearchTime(String lastName, boolean noCache)
    {
    	if (lastName == null || lastName.isEmpty())
    	{
            System.out.println("Error: cannot search for empty last name.");
    		return 0;
    	}
    	
		System.out.print("	Searching for patient [" + lastName.toUpperCase() + "]...");
		MyClientInterceptor performance = new MyClientInterceptor();
        client.registerInterceptor(performance);

		// Search for Patient resources
        @SuppressWarnings("unused")
		Bundle response = client
                .search()
                .forResource("Patient")
                .where(Patient.FAMILY.matches().value(lastName.toUpperCase()))
//              .where(Patient.FAMILY.matches().value("SMITH"))
                .returnBundle(Bundle.class)
                .cacheControl(new CacheControlDirective().setNoCache(noCache))                
                .execute();
        
        long timeTaken = performance.getTimeTaken();
        client.unregisterInterceptor(performance);
        
        return timeTaken;
    }

    
    @SuppressWarnings("unused")
	private static void printPatients(Bundle response)
    {
        if ("Bundle".equals(response.fhirType()))
  		{
    		List<BundleEntryComponent> entries = ((Bundle) response).getEntry(); 
            System.out.println("	Query returned " + entries.size() + " entries.");

        	for (BundleEntryComponent entry : entries)
        	{
	            if ("Patient".equalsIgnoreCase(entry.getResource().getResourceType().name()))
				{
					Patient fhirPatient = (Patient) entry.getResource();
					Date birthday = fhirPatient.getBirthDate();
					String fullName = "";
					List<HumanName> names = fhirPatient.getName();
					for (HumanName name : names)
					{
						// name.getText() may be null even though last name and given are not;
						// fullName += name.getText() + " ";
						
						fullName += name.getFamily() + ", " + getFirst(name);
					}
    	            System.out.println("	Name: " + fullName + "| Birthday: " + birthday);
				}
        	}
  		}
    }
    
    
    private static String getFirst(HumanName name)
    {
    	String firstName = "";
    	for (StringType givenName : name.getGiven())
    	{
    		firstName += givenName + " ";
    	}
    	return firstName;
    }


	@SuppressWarnings("unused")
	private static String readFileWithNames(String fileName)
    {
 	   String fileStr = null;
		try
		{
			fileStr = TextFile.fileToString(fileName);
		}
		catch (FileNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 	   return fileStr;
    }

	
	private static long calcAverage(ArrayList<Long> values)
	{
		if (values == null || values.size() == 0)
		{
			return 0;
		}
		
		long sum = 0;
		for (Long value: values)
		{
			sum += value.longValue();
		}
		return sum/values.size();
	}

}
